# Claude Code Docker + iptables 隔離テンプレート

Ubuntu ベースの Docker コンテナ内で Claude Code を実行し、コンテナ内 `iptables` / `ipset` で egress を allowlist 制御するテンプレートです。Linux / WSL2 の Claude Code 組み込み Bash sandbox が使う `socat` を避けるため、Claude Code の組み込み sandbox は `managed-settings.json` で無効化しています。

## セキュリティ方針

このテンプレートは、主に以下を目的にしています。

- Claude Code と Bash tool の実行範囲を Docker コンテナ内に閉じ込める。
- ホストの `~/.ssh`、`~/.aws`、`~/.kube`、`~/.docker/config.json` などをマウントしない。
- コンテナ起動時に `iptables` / `ipset` を設定し、allowlist された宛先だけに outbound TCP を許可する。
- IPv6 をデフォルトで遮断する。
- DNS を初期解決にだけ使い、`FIREWALL_BLOCK_DNS_AFTER_INIT=1` の場合は起動後の DNS egress を遮断する。
- Claude Code の managed settings で MCP、hooks、plugin、remote control、bypass permissions、自動更新、非必須トラフィックを制限する。
- `socat` をイメージに含めず、存在した場合は Docker build を失敗させる。

## ファイル構成

```text
.
├── Dockerfile
├── docker-compose.yml
├── .env.example
├── config/
│   ├── egress-allow-cidrs.txt
│   ├── egress-allow-domains.txt
│   └── managed-settings.json
└── scripts/
    ├── check-firewall.sh
    ├── entrypoint.sh
    └── init-firewall.sh
```

## 使い方

### 1. allowlist を編集する

`config/egress-allow-domains.txt` を会社の環境に合わせて編集してください。

最初は次のような宛先だけを残すことを推奨します。

```text
api.anthropic.com
claude.ai
platform.claude.com
github.example.com
registry.npmjs.example.com
pypi.example.com
proxy.example.com
```

GitHub Enterprise Server、社内 npm mirror、社内 PyPI mirror、社内 LLM gateway / proxy を使う場合は、パブリック GitHub やパブリック registry を削除してください。

`config/egress-allow-cidrs.txt` は、ネットワーク管理部署が安定した CIDR を提供できる場合だけ使ってください。

### 2. build する

```bash
docker compose build --pull
```

### 3. 起動する

プロジェクトのルートディレクトリで、次のように起動します。

```bash
HOST_UID=$(id -u) HOST_GID=$(id -g) WORKSPACE=$PWD docker compose run --rm claude-code
```

コンテナ内で Claude Code を起動します。

```bash
claude
```

初回ログイン情報は Docker volume `claude-home` に保存されます。ホストの `~/.claude` はマウントしません。

### 4. firewall を確認する

コンテナ内で次を実行してください。

```bash
check-firewall
```

期待値:

- `socat present: no`
- `example.com:443` はブロックされる
- allowlist の先頭ドメインは到達できる、または社内 proxy / firewall の設定に応じて警告になる

## 企業 proxy を使う場合

proxy を使う場合は、proxy の FQDN を `config/egress-allow-domains.txt` に追加し、proxy の port も許可してください。

例:

```bash
HTTPS_PROXY=http://proxy.example.com:8080 \
HTTP_PROXY=http://proxy.example.com:8080 \
FIREWALL_ALLOWED_TCP_PORTS="443 8080" \
HOST_UID=$(id -u) HOST_GID=$(id -g) WORKSPACE=$PWD \
docker compose run --rm claude-code
```

より厳格にするなら、外部サービスのドメインを直接 allowlist せず、proxy / LLM gateway / artifact repository だけを allowlist してください。

## Bedrock / Vertex / Foundry / 社内 LLM gateway を使う場合

`api.anthropic.com`、`claude.ai`、`platform.claude.com` が不要になる構成もあります。利用する provider / gateway の endpoint だけを `egress-allow-domains.txt` に残してください。

例:

```text
bedrock-runtime.ap-northeast-1.amazonaws.com
sts.ap-northeast-1.amazonaws.com
company-llm-gateway.example.com
```

認証方式に応じて環境変数を Compose 側または会社管理の credential helper で設定してください。クラウドの長期 credential をホストからマウントする運用は避けてください。

## 重要な制約

### Docker 利用権限は強い権限です

Linux でユーザーが Docker socket を自由に使える場合、そのユーザーは実質的にホスト root 相当の操作ができます。このテンプレートは「Claude Code とその子プロセスの事故・過剰動作をコンテナ内に閉じ込める」ためのものです。悪意あるローカルユーザーや、Docker Compose を自由に改変できるユーザーに対する完全な強制境界にはなりません。

運用管理部署が仮想マシンを配布する場合は、次も併用してください。

- Docker socket の利用者を限定する。
- 配布イメージを署名・固定する。
- compose / Dockerfile の改変を検知する。
- ホスト側の `DOCKER-USER` chain、EDR、iptables / nftables、proxy、DNS logging で二重に制御する。
- VM からの egress をネットワーク境界でも制御する。

### コンテナ内 firewall には NET_ADMIN / NET_RAW が必要です

`docker-compose.yml` では、entrypoint が firewall を設定するために `NET_ADMIN` と `NET_RAW` を付与しています。entrypoint は root で iptables を設定したあと、`gosu` で非 root ユーザー `claude` に降格します。

より強い運用では、コンテナ内 firewall ではなく、ホスト側 `DOCKER-USER` chain や VM / VPC / proxy 側で egress を強制し、アプリコンテナから `NET_ADMIN` / `NET_RAW` を取り除いてください。

### FQDN allowlist は起動時解決です

iptables は FQDN を直接評価しません。このテンプレートでは起動時に allowlist の FQDN を IP に解決し、`ipset` に登録します。`FIREWALL_BLOCK_DNS_AFTER_INIT=1` の場合、解決結果を `/etc/hosts` に追記して起動後の DNS を遮断します。

そのため、CDN や SaaS の IP が変化した場合は、コンテナを再起動して allowlist を再解決してください。

### デフォルトでは SSH Git を使わせません

`managed-settings.json` では Claude Code の Bash tool からの `ssh` / `scp` / `rsync` を deny しています。GitHub / GitLab は HTTPS clone を優先してください。SSH が必要な場合でも、ホストの `~/.ssh` を直接マウントするのは避け、短命 credential、社内 proxy、または専用 deploy key を検討してください。

## よく変える設定

### DNS を起動後も許可する

互換性を優先する場合:

```bash
FIREWALL_BLOCK_DNS_AFTER_INIT=0 docker compose run --rm claude-code
```

ただし、DNS query を使った情報持ち出し経路が残ります。

### HTTP proxy の port を許可する

```bash
FIREWALL_ALLOWED_TCP_PORTS="443 8080" docker compose run --rm claude-code
```

### workspace の所有者問題を直す

```bash
CHOWN_WORKSPACE=1 HOST_UID=$(id -u) HOST_GID=$(id -g) WORKSPACE=$PWD docker compose run --rm claude-code
```

大きな repository では時間がかかるため、通常は `HOST_UID` / `HOST_GID` の一致で解決してください。

## 運用前チェックリスト

- [ ] `config/egress-allow-domains.txt` から不要なパブリック宛先を削除した。
- [ ] `check-firewall` で `example.com` がブロックされることを確認した。
- [ ] `socat` が image に含まれていないことを確認した。
- [ ] ホストの `~/.ssh`、`~/.aws`、`~/.kube`、`~/.docker` をマウントしていない。
- [ ] Docker 利用権限の付与対象を限定した。
- [ ] 管理部署が配布する場合、VM / host firewall / proxy 側でも egress を制御した。
- [ ] Claude Code の更新手順を中央管理にした。`DISABLE_UPDATES=1` を入れているため、ユーザーによる自己更新は無効です。
