# ホスト側 DOCKER-USER chain による追加制御メモ

このテンプレートのデフォルトは「コンテナ内で iptables を設定する」方式です。配布 VM を運用管理部署が管理できる場合は、ホスト側の `DOCKER-USER` chain でも制御すると、コンテナが `NET_ADMIN` を持つ時間を短くできます。

Docker は Docker 管理ルールより前に `DOCKER-USER` chain を評価します。したがって、特定の Docker bridge subnet からの外向き通信をホスト側で制限できます。

概念例:

```bash
# 例: claude-code 用 network subnet を 172.30.50.0/24 に固定している場合
sudo iptables -I DOCKER-USER -s 172.30.50.0/24 -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
sudo iptables -I DOCKER-USER -s 172.30.50.0/24 -d <proxy-or-gateway-ip> -p tcp --dport 443 -j ACCEPT
sudo iptables -A DOCKER-USER -s 172.30.50.0/24 -j REJECT --reject-with icmp-admin-prohibited
```

本番運用では、Docker network の subnet を compose で固定し、proxy / LLM gateway / artifact repository の固定 IP または社内 DNS / firewall と組み合わせてください。FQDN ベースの allowlist を iptables だけで厳密に実装することはできないため、社内 proxy 側で SNI / HTTP Host / 認証 / 監査を行う構成がより堅牢です。
