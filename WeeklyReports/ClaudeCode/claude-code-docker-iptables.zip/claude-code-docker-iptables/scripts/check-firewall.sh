#!/usr/bin/env bash
set -Eeuo pipefail

allowlist="${EGRESS_ALLOWLIST:-/etc/claude-code/egress-allow-domains.txt}"

trim_line() {
  local s="${1%%#*}"
  s="$(printf '%s' "$s" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')"
  printf '%s' "$s"
}

printf '[check] effective user: %s\n' "$(id)"
printf '[check] socat present: '
if command -v socat >/dev/null 2>&1; then
  printf 'YES - unexpected\n'
  exit 1
else
  printf 'no\n'
fi

printf '[check] blocked domain example.com:443: '
if timeout 6 bash -c '</dev/tcp/example.com/443' >/dev/null 2>&1; then
  printf 'FAIL - reachable\n'
  exit 1
else
  printf 'OK - blocked\n'
fi

first_domain=""
while IFS= read -r line || [[ -n "$line" ]]; do
  item="$(trim_line "$line")"
  [[ -z "$item" ]] && continue
  first_domain="$item"
  break
done < "$allowlist"

if [[ -n "$first_domain" ]]; then
  printf '[check] first allowlisted domain %s:443: ' "$first_domain"
  if timeout 8 bash -c "</dev/tcp/$first_domain/443" >/dev/null 2>&1; then
    printf 'OK - reachable\n'
  else
    printf 'WARN - not reachable; check allowlist, proxy, or corporate firewall\n'
  fi
fi

printf '[check] iptables OUTPUT policy:\n'
iptables -S OUTPUT || true
