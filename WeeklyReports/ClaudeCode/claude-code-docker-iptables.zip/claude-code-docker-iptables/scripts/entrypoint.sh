#!/usr/bin/env bash
set -Eeuo pipefail

log() { printf '[entrypoint] %s\n' "$*"; }
warn() { printf '[entrypoint] WARN: %s\n' "$*" >&2; }

is_int() { [[ "${1:-}" =~ ^[0-9]+$ ]]; }
is_truthy() {
  case "${1:-}" in
    1|true|TRUE|yes|YES|on|ON) return 0 ;;
    *) return 1 ;;
  esac
}

run_user="${CLAUDE_RUN_USER:-claude}"
host_uid="${HOST_UID:-1000}"
host_gid="${HOST_GID:-1000}"

if [[ "$(id -u)" != "0" ]]; then
  echo "entrypoint must start as root so it can install iptables rules; refusing to continue" >&2
  exit 1
fi

if ! id "$run_user" >/dev/null 2>&1; then
  echo "user not found: $run_user" >&2
  exit 1
fi

# Align the in-container user with the host UID/GID to avoid bind-mount permission issues.
if is_int "$host_gid" && [[ "$(id -g "$run_user")" != "$host_gid" ]]; then
  if getent group "$host_gid" >/dev/null 2>&1; then
    existing_group="$(getent group "$host_gid" | cut -d: -f1)"
    usermod -g "$existing_group" "$run_user"
  else
    groupmod -g "$host_gid" "$run_user"
  fi
fi

if is_int "$host_uid" && [[ "$(id -u "$run_user")" != "$host_uid" ]]; then
  if getent passwd "$host_uid" >/dev/null 2>&1; then
    warn "UID $host_uid already exists in container; keeping existing UID for $run_user"
  else
    usermod -u "$host_uid" "$run_user"
  fi
fi

user_home="$(getent passwd "$run_user" | cut -d: -f6)"
mkdir -p "$user_home/.claude" "$user_home/.cache" /workspace
chown -R "$run_user":"$(id -gn "$run_user")" "$user_home"

if is_truthy "${CHOWN_WORKSPACE:-0}"; then
  log "chowning /workspace to $run_user; this may be slow on large repositories"
  chown -R "$run_user":"$(id -gn "$run_user")" /workspace
fi

if is_truthy "${FIREWALL_ENABLED:-1}"; then
  /usr/local/sbin/init-firewall.sh
else
  warn "FIREWALL_ENABLED is disabled; egress is unrestricted from inside this container"
fi

log "starting as $(id -u "$run_user"):$(id -g "$run_user") in /workspace"
exec gosu "$run_user" "$@"
