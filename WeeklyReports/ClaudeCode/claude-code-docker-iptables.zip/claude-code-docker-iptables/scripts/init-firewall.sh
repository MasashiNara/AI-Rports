#!/usr/bin/env bash
set -Eeuo pipefail

log() { printf '[firewall] %s\n' "$*"; }
warn() { printf '[firewall] WARN: %s\n' "$*" >&2; }
die() { printf '[firewall] ERROR: %s\n' "$*" >&2; exit 1; }

require_cmd() {
  command -v "$1" >/dev/null 2>&1 || die "missing required command: $1"
}

trim_line() {
  local s="${1%%#*}"
  # shellcheck disable=SC2001
  s="$(printf '%s' "$s" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')"
  printf '%s' "$s"
}

is_truthy() {
  case "${1:-}" in
    1|true|TRUE|yes|YES|on|ON) return 0 ;;
    *) return 1 ;;
  esac
}

valid_port() {
  [[ "$1" =~ ^[0-9]+$ ]] && (( "$1" >= 1 && "$1" <= 65535 ))
}

valid_domain() {
  # Intentionally conservative. Wildcards are not supported because iptables cannot enforce FQDN wildcards.
  [[ "$1" =~ ^[A-Za-z0-9.-]+$ ]] && [[ "$1" == *.* ]] && [[ "$1" != *'*'* ]]
}

allow_domains_file="${EGRESS_ALLOWLIST:-/etc/claude-code/egress-allow-domains.txt}"
allow_cidrs_file="${EGRESS_ALLOW_CIDRS:-/etc/claude-code/egress-allow-cidrs.txt}"
block_dns_after_init="${FIREWALL_BLOCK_DNS_AFTER_INIT:-1}"
enable_ipv6="${FIREWALL_ENABLE_IPV6:-0}"
verify_firewall="${FIREWALL_VERIFY:-1}"
allowed_tcp_ports="${FIREWALL_ALLOWED_TCP_PORTS:-443}"

ipset4="claude_egress_v4"
ipset6="claude_egress_v6"

require_cmd iptables
require_cmd ipset
require_cmd getent
require_cmd awk
require_cmd sed

if [[ ! -r "$allow_domains_file" ]]; then
  die "allowlist file not readable: $allow_domains_file"
fi
if [[ ! -r "$allow_cidrs_file" ]]; then
  die "CIDR allowlist file not readable: $allow_cidrs_file"
fi

for port in $allowed_tcp_ports; do
  valid_port "$port" || die "invalid port in FIREWALL_ALLOWED_TCP_PORTS: $port"
done

mapfile -t domains < <(
  while IFS= read -r line || [[ -n "$line" ]]; do
    item="$(trim_line "$line")"
    [[ -z "$item" ]] && continue
    valid_domain "$item" || die "invalid or unsupported domain in $allow_domains_file: $item"
    printf '%s\n' "$item"
  done < "$allow_domains_file" | sort -u
)

log "initializing egress firewall"
log "domain allowlist: ${#domains[@]} domain(s)"
log "allowed TCP ports: $allowed_tcp_ports"
log "block DNS after init: $block_dns_after_init"
log "IPv6 enabled: $enable_ipv6"

# Do not flush the nat table. Docker's embedded DNS relies on nat rules for 127.0.0.11.
iptables -F INPUT || true
iptables -F OUTPUT || true
iptables -F FORWARD || true
iptables -X || true

ipset destroy "$ipset4" 2>/dev/null || true
ipset create "$ipset4" hash:net family inet hashsize 1024 maxelem 65536

if is_truthy "$enable_ipv6"; then
  ipset destroy "$ipset6" 2>/dev/null || true
  ipset create "$ipset6" hash:net family inet6 hashsize 1024 maxelem 65536
fi

add_hosts_entry() {
  local ip="$1"
  local domain="$2"
  if is_truthy "$block_dns_after_init"; then
    printf '%s\t%s\t# claude-code-firewall\n' "$ip" "$domain" >> /etc/hosts || warn "could not append /etc/hosts entry for $domain"
  fi
}

add_ipv4() {
  local value="$1"
  ipset add "$ipset4" "$value" -exist
}

add_ipv6() {
  local value="$1"
  if is_truthy "$enable_ipv6"; then
    ipset add "$ipset6" "$value" -exist
  fi
}

# Add static CIDRs first.
while IFS= read -r line || [[ -n "$line" ]]; do
  cidr="$(trim_line "$line")"
  [[ -z "$cidr" ]] && continue
  if [[ "$cidr" == *:* ]]; then
    add_ipv6 "$cidr"
  else
    add_ipv4 "$cidr"
  fi
  log "allowed static CIDR: $cidr"
done < "$allow_cidrs_file"

# Resolve exact domains at startup. This is intentionally fail-closed: if a domain cannot be resolved,
# the container exits so users do not accidentally run with a partially-open policy.
for domain in "${domains[@]}"; do
  log "resolving $domain"
  mapfile -t ipv4s < <(getent ahostsv4 "$domain" | awk '{print $1}' | sort -u)

  if [[ "${#ipv4s[@]}" -eq 0 ]]; then
    die "failed to resolve IPv4 for allowed domain: $domain"
  fi

  for ip in "${ipv4s[@]}"; do
    add_ipv4 "$ip/32"
    add_hosts_entry "$ip" "$domain"
    log "  + $ip"
  done

  if is_truthy "$enable_ipv6"; then
    mapfile -t ipv6s < <(getent ahostsv6 "$domain" | awk '{print $1}' | sort -u || true)
    for ip in "${ipv6s[@]}"; do
      add_ipv6 "$ip/128"
      add_hosts_entry "$ip" "$domain"
      log "  + $ip"
    done
  fi
done

# Apply IPv4 filter policy.
iptables -P INPUT DROP
iptables -P FORWARD DROP
iptables -P OUTPUT DROP

iptables -A INPUT -i lo -j ACCEPT
iptables -A OUTPUT -o lo -j ACCEPT
iptables -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
iptables -A OUTPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT

# DNS is needed during initialization only. Keeping it open is more compatible but permits DNS-based exfiltration.
if ! is_truthy "$block_dns_after_init"; then
  iptables -A OUTPUT -p udp --dport 53 -j ACCEPT
  iptables -A OUTPUT -p tcp --dport 53 -j ACCEPT
fi

for port in $allowed_tcp_ports; do
  iptables -A OUTPUT -p tcp -m set --match-set "$ipset4" dst --dport "$port" -j ACCEPT
done

iptables -A OUTPUT -j REJECT --reject-with icmp-admin-prohibited

# Default: block IPv6 completely. This prevents IPv6 bypass when only IPv4 allowlists are maintained.
if command -v ip6tables >/dev/null 2>&1; then
  ip6tables -F INPUT || true
  ip6tables -F OUTPUT || true
  ip6tables -F FORWARD || true
  ip6tables -X || true
  ip6tables -P INPUT DROP
  ip6tables -P FORWARD DROP
  ip6tables -P OUTPUT DROP
  ip6tables -A INPUT -i lo -j ACCEPT
  ip6tables -A OUTPUT -o lo -j ACCEPT
  ip6tables -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
  ip6tables -A OUTPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT

  if is_truthy "$enable_ipv6"; then
    if ! is_truthy "$block_dns_after_init"; then
      ip6tables -A OUTPUT -p udp --dport 53 -j ACCEPT
      ip6tables -A OUTPUT -p tcp --dport 53 -j ACCEPT
    fi
    for port in $allowed_tcp_ports; do
      ip6tables -A OUTPUT -p tcp -m set --match-set "$ipset6" dst --dport "$port" -j ACCEPT
    done
    ip6tables -A OUTPUT -j REJECT --reject-with icmp6-adm-prohibited
  fi
fi

if is_truthy "$verify_firewall"; then
  log "verifying blocked egress to example.com:443"
  if timeout 6 bash -c '</dev/tcp/example.com/443' >/dev/null 2>&1; then
    die "firewall verification failed: example.com:443 is reachable but is not allowlisted"
  fi
  log "blocked egress verification passed"
fi

log "egress firewall active"
